# Auth Webapp (React + Firebase)

Simple React app with Sign Up / Login flow using Firebase Authentication.

## Features
- Email/password sign up and login
- Client-side validation and error messages
- Protected dashboard (`/dashboard`) that shows "Welcome, {email}"
- Ready-to-deploy to Vercel / Netlify / Render
- Instructions to enable an n8n webhook for new signups (optional)

## Setup (local)
1. Install dependencies:
   ```
   npm install
   ```
2. Create a Firebase project at https://console.firebase.google.com/
   - Enable **Email/Password** sign-in method in **Authentication**.
   - Go to project settings -> SDK (Firebase SDK) and copy the config object.

3. Create a file `.env` in the project root with:
   ```
   REACT_APP_FIREBASE_API_KEY=your_api_key
   REACT_APP_FIREBASE_AUTH_DOMAIN=your_auth_domain
   REACT_APP_FIREBASE_PROJECT_ID=your_project_id
   REACT_APP_FIREBASE_STORAGE_BUCKET=your_storage_bucket
   REACT_APP_FIREBASE_MESSAGING_SENDER_ID=your_sender_id
   REACT_APP_FIREBASE_APP_ID=your_app_id
   ```

4. Run locally:
   ```
   npm start
   ```

## Deploy (Vercel / Netlify)
1. Push this repo to GitHub.
2. On Vercel / Netlify, create a new project and connect to the GitHub repo.
3. Add the same environment variables listed above in the platform's settings.
4. Build command: `npm run build`, Publish directory: `build`.

## n8n (bonus - optional)
If you want to trigger an n8n workflow on every signup:
1. Create an n8n webhook URL.
2. In Firebase console, under Authentication -> Triggers, or by using Firebase Cloud Functions, call the webhook on new user creation. Alternatively, in this app after successful signup we POST to the webhook (see `src/n8n-example.js`).

## Files included
- src/ (React code)
- public/
- README.md

// Example snippet showing how this app posts to an n8n webhook after signup.
// Put REACT_APP_N8N_WEBHOOK in your .env to enable the POST request in Signup.js
// n8n webhook should accept JSON POST and then you can add nodes to send email, Google Sheets, etc.

export async function triggerN8n(webhookUrl, payload) {
  try {
    const res = await fetch(webhookUrl, {
      method: 'POST', headers: {'Content-Type':'application/json'}, body: JSON.stringify(payload)
    });
    return res.ok;
  } catch (err) {
    return false;
  }
}

// src/firebase.js
import { initializeApp } from "firebase/app";
import { getAuth, createUserWithEmailAndPassword, signInWithEmailAndPassword, signOut } from "firebase/auth";
import { createContext, useContext } from "react";

// 🔹 Firebase config
const firebaseConfig = {
  apiKey: "AIzaSyAX-D6R8aMsWtibBWtSzrv3yZBnyPuXSag",
  authDomain: "auth-web-app-b27b0.firebaseapp.com",
  projectId: "auth-web-app-b27b0",
  storageBucket: "auth-web-app-b27b0.firebasestorage.app",
  messagingSenderId: "732402945120",
  appId: "1:732402945120:web:6a8370ee8b77d5f7614705"
};

// 🔹 Initialize Firebase
const app = initializeApp(firebaseConfig);
export const auth = getAuth(app);

// 🔹 Auth context
const AuthContext = createContext();

export function AuthProvider({ children }) {
  return <AuthContext.Provider value={{ auth }}>{children}</AuthContext.Provider>;
}

export function useAuth() {
  return useContext(AuthContext);
}

// 🔹 Auth helper functions
export const signup = (email, password) => createUserWithEmailAndPassword(auth, email, password);
export const login = (email, password) => signInWithEmailAndPassword(auth, email, password);
export const logout = () => signOut(auth);

// src/components/Dashboard.js
import React from "react";
import { logout } from "../firebase";
import { useNavigate } from "react-router-dom";

export default function Dashboard() {
  const navigate = useNavigate();

  const handleLogout = async () => {
    await logout();
    navigate("/login");
  };

  return (
    <div style={{ textAlign: "center", marginTop: "50px" }}>
      <h1>Welcome, User</h1>
      <button
        onClick={handleLogout}
        style={{ padding: "10px 20px", borderRadius: "4px", backgroundColor: "#f44336", color: "#fff", border: "none", marginTop: "20px" }}
      >
        Logout
      </button>
    </div>
  );
}
